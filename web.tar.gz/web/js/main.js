document.getElementById("pingBtn").onclick = function () {
    fetch("/api/ping")
        .then(r => r.json())
        .then(data => {
            document.getElementById("output").innerText = JSON.stringify(data, null, 2);
        })
        .catch(err => {
            document.getElementById("output").innerText = "请求失败: " + err;
        });
};
